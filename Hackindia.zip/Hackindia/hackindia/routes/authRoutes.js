// routes/authRoutes.js
const express = require('express');
const router = express.Router();

// Sample routes for login and signup (You can replace them with actual logic)
router.post('/login', (req, res) => {
  // Handle login logic
  res.send('Login route');
});

router.post('/signup', (req, res) => {
  // Handle signup logic
  res.send('Signup route');
});

module.exports = router;
