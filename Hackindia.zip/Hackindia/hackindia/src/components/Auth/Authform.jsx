import React, { useState } from 'react';
import './AuthForm.css';

const AuthForm = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const [message, setMessage] = useState('');

  const handleChange = (e) => setFormData({ ...formData, [e.target.id]: e.target.value });

  const togglePassword = () => {
    const input = document.getElementById('password');
    input.type = input.type === 'password' ? 'text' : 'password';
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isLogin) {
      const user = JSON.parse(localStorage.getItem(formData.email));
      if (!user) return setMessage('User not found!');
      if (user.password !== formData.password) return setMessage('Incorrect password');
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('loggedInUser', formData.email);
      onLogin(); // Callback to redirect
    } else {
      if (localStorage.getItem(formData.email)) return setMessage('Email already registered');
      localStorage.setItem(formData.email, JSON.stringify({ name: formData.name, password: formData.password }));
      setMessage('Registered successfully!');
      setIsLogin(true);
    }
  };

  return (
    <div className="auth-container">
      <h2>{isLogin ? 'Login' : 'Register'}</h2>
      <form onSubmit={handleSubmit}>
        {!isLogin && (
          <input id="name" type="text" placeholder="Name" value={formData.name} onChange={handleChange} required />
        )}
        <input id="email" type="email" placeholder="Email" value={formData.email} onChange={handleChange} required />
        <div className="password-field">
          <input id="password" type="password" placeholder="Password" value={formData.password} onChange={handleChange} required />
          <button type="button" onClick={togglePassword}>👁️</button>
        </div>
        <button type="submit">{isLogin ? 'Login' : 'Register'}</button>
      </form>
      <p>{isLogin ? "Don't have an account?" : "Already have an account?"} <span onClick={() => setIsLogin(!isLogin)}>{isLogin ? 'Register here' : 'Login here'}</span></p>
      {message && <p className="message">{message}</p>}
    </div>
  );
};

export default AuthForm;